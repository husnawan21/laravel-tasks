@extends('layouts.app', ['title' => 'Blog'])
@section('content')
  <article class="prose mx-auto my-12 px-5">
    <h1>Post</h1>
  </article>
@endsection
