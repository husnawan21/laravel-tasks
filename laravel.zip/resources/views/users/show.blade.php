<x-app-layout title="{{ $user->name }}">
  <article class="prose mx-auto px-5 pb-12 pt-20">
    <h1>{{ $user->name }}</h1>
    <h2 class="text-secondary">{{ $user->username }}</h2>
    <div>

    </div>
  </article>
</x-app-layout>
