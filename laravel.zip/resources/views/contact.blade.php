<x-app-layout title="Contact">

  <article class="prose mx-auto my-12 px-5">
    <h1>Contact</h1>
  </article>

</x-app-layout>
