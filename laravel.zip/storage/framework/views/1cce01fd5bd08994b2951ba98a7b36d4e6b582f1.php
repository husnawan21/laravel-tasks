<div>
  ini adalah app
</div>
<?php /**PATH D:\Project\Applications\laravel-prs\resources\views/components/layouts/app.blade.php ENDPATH**/ ?>