<form action="/tasks" method="post">
  <?php echo csrf_field(); ?>
  <?php echo $__env->make('tasks._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php $__errorArgs = ['list'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="text-red-600">
      <?php echo e($message); ?>

    </p>
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</form>
<?php /**PATH D:\Project\Applications\laravel-prs\resources\views/tasks/_create.blade.php ENDPATH**/ ?>