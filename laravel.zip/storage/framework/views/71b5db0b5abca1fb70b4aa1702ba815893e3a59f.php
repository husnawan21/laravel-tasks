<div class="form-control">
  <div class="input-group">
    <input type="text" placeholder="Enter your task.." value="<?php echo e(old('list') ?? $task->list); ?>"
      class="input input-bordered w-full <?php $__errorArgs = ['list'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="list" />
    <button class="btn btn-square" type="submit">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"
        class="w-5 h-5">
        <path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12.75l6 6 9-13.5" />
      </svg>
    </button>
  </div>
</div>
<?php /**PATH D:\Project\Applications\laravel-prs\resources\views/tasks/_form.blade.php ENDPATH**/ ?>