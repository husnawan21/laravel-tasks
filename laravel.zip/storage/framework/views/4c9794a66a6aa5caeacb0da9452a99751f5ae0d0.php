<div>
  ini adalah app comp
</div>
<?php /**PATH D:\Project\Applications\laravel-prs\resources\views/components/app-layout.blade.php ENDPATH**/ ?>