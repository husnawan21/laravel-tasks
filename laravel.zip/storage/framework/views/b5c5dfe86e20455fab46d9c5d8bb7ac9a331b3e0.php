<?php $__env->startSection('content'); ?>
  <h1>First Post</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Blog'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Applications\laravel-prs\resources\views/posts/show.blade.php ENDPATH**/ ?>